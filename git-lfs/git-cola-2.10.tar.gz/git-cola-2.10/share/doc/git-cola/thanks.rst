Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Aaron Cook
* Aaron Wolf
* Adrien be
* AJ Bagwell
* Alex Chernetz
* Alexander Kozienko
* Alf Eaton
* anderben
* Andreas Sommer
* Andrew Chen
* Audrius Karabanovas
* Barış ÇELİK
* Barry Roberts
* Boris W
* Ben Boeckel
* Ben Cole
* Benedict Lee
* Benoît Nouyrigat
* Bert Jacobs
* Charles 101
* Christian Jann
* Christopher Meng
* Clément Pit--Claudel
* Daniel Fahlke
* Daniel Jay Haskin
* Daniel Harding
* Daniel King
* Dave Thomas
* David Aguilar
* David LeGare
* David Martínez Martí
* Dawid Drozd
* Dennis Gilmore
* deniz1a
* Dmitry Kann
* Drugoy
* Eric Drechsel
* Fabio Coatti
* Garoe Dorta
* Geoffrey van Wyk
* geotavros
* `Git Hackers <http://git-scm.com/about>`_
* Glen Mailer
* Guillaume de Bure
* Guo Yunhe
* Harro Verton
* Igor Galarraga
* Ilya Tumaykin
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jan @hanksoff
* Jakub Wilk
* James Geiger
* Jeff Dagenais
* Jérôme Carretero
* JiCiT
* Johann Schmitz
* Jordan Bedwell
* Josh Taylor
* Justin Lecher
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Kirit Sælensminde
* László Böszörményi
* Leho Kraav
* Lev Zlotin
* Libor Jelinek
* Liviu Cristian Mirea-Ghiban
* Łukasz Wojniłowicz
* Luke Bakken
* Maarten Nieber
* Maaaks
* Maciej Filipiak
* Mahmoud Hossam
* Mateusz Kedzior
* Maicon D. Filippsen
* Marco Costalba
* Markus Heidelberg
* Matěj Šmíd
* Matthew Levine
* Matthias Mailänder
* Micha Rosenbaum
* Michael Geddes
* Michael Homer
* MikHulk
* Minarto Margoliono
* Naraesk
* Nicolas Dietrich
* OmegaPhil (Omega Weapon)
* Owen Healy
* Pamela Strucker
* Paolo G. Giarrusso
* Parashurama Rhagdamaziel
* Patrick Browne
* Paul Hildebrandt
* Paul Weingardt
* Paulo Fidalgo
* Peter Dave Hello
* Peter Júnoš
* Philip Stark
* Pilar Molina Lopez
* Raghavendra Karunanidhi
* Rainer Müller
* Rolando Espinoza La fuente
* Rustam Safin
* Samsul Ma'arif
* Sebastian Brass
* Sergey Leschina
* Srinivasa Nallapati
* Stan Angeloff
* Stanisław Halik
* Stefan Naewe
* Steffen Prohaska
* Sven Claussner
* Taylor Braun-Jones
* Thiemo van Engelen
* Thomas Kluyver
* Trevor Alexander
* Ugo Riboni
* Uri Okrent
* Utku Karatas
* Ｖ字龍 (Vdragon)
* Vaibhav Sagar
* Vaiz
* Ved Vyas
* Ville Skyttä
* Virgil Dupras
* Vitor Lobo
* v.paritskiy
* Wolfgang Ocker
* Yi EungJun
* Zeioth
* Zhang Han
